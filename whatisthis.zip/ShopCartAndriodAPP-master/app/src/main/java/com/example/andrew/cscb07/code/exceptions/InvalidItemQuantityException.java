package com.example.andrew.cscb07.code.exceptions;

/**
 * Created by LTJ on 2017/11/29.
 */

public class InvalidItemQuantityException extends Exception {
    private static final long serialVersionUID = 38195781106910585L;
}
