package com.example.andrew.cscb07.code.exceptions;

/**
 * Created by LTJ on 2017/11/29.
 */

public class InvalidAddressExcetpion extends Exception{
    private static final long serialVersionUID = 123213120L;
}
