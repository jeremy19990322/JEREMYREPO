package com.example.andrew.cscb07.code.exceptions;

/**
 * Created by LTJ on 2017/12/4.
 */

public class InvalidItemNameException extends Exception {
    private static final long serialVersionUID = 1231023908124L;
}
