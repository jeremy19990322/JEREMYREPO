package com.example.andrew.cscb07.code.com.users;

/**
 * Created by LTJ on 2017/11/28.
 */

public enum Roles {
    ADMIN,
    CUSTOMER,
    EMPLOYEE
}
