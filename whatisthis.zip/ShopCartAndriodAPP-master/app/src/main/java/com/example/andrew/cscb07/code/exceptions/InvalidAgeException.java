package com.example.andrew.cscb07.code.exceptions;

/**
 * Created by LTJ on 2017/11/29.
 */

public class InvalidAgeException extends Exception {
    private static final long serialVersionUID = 143129012105L;
}
