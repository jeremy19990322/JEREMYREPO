package com.example.andrew.cscb07.code.exceptions;

/**
 * Created by LTJ on 2017/11/29.
 */

public class InvalidTotalPriceException extends Exception {
    private static final long serialVersionUID = 381957811067491058L;
}
